<?php return array (
  'title' => 'Team: 2 Columns',
  'elements' => 
  array (
    0 => 
    array (
      'elType' => 'section',
      'title' => 'Team: 2 Columns',
      'elements' => 
      array (
        0 => 
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/2 + 1/2',
          'marginlessColumns' => false,
          'elements' => 
          array (
            0 => 
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' => 
              array (
                0 => 
                array (
                  'elType' => 'promo',
                  'content' => '<h3 class="man">Terry</h3>
<h4 class="h5 man">CEO</h4>
[x_gap size="10px"]
<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut mollis.</p>
[x_gap size="10px"] <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="linkedin-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="facebook-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="twitter-square"] </a>',
                  'image' => 'http://placehold.it/750x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 => 
                array (
                  'elType' => 'gap',
                  'gap_size' => '45px',
                  'visibility' => 
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 => 
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' => 
              array (
                0 => 
                array (
                  'elType' => 'promo',
                  'content' => '<h3 class="man">Jillian</h3>
<h4 class="h5 man">Marketing</h4>
[x_gap size="10px"]
<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut mollis.</p>
[x_gap size="10px"]<a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="linkedin-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="facebook-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="twitter-square"] </a>',
                  'image' => 'http://placehold.it/750x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
            ),
            2 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' => 
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' => 
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' => 
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' => 
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
        1 => 
        array (
          'elType' => 'row',
          'title' => 'Copy of Row 1',
          'columnLayout' => '1/2 + 1/2',
          'marginlessColumns' => false,
          'elements' => 
          array (
            0 => 
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' => 
              array (
                0 => 
                array (
                  'elType' => 'promo',
                  'content' => '<h3 class="man">Frank</h3>
<h4 class="h5 man">Legal</h4>
[x_gap size="10px"]
<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut mollis.</p>
[x_gap size="10px"] <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="linkedin-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="facebook-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="twitter-square"] </a>',
                  'image' => 'http://placehold.it/750x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                1 => 
                array (
                  'elType' => 'gap',
                  'gap_size' => '45px',
                  'visibility' => 
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 => 
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' => 
              array (
                0 => 
                array (
                  'elType' => 'promo',
                  'content' => '<h3 class="man">Terry</h3>
<h4 class="h5 man">CEO</h4>
[x_gap size="10px"]
<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut mollis.</p>
[x_gap size="10px"] <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="linkedin-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="facebook-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="twitter-square"] </a>',
                  'image' => 'http://placehold.it/750x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
            ),
            2 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' => 
          array (
            0 => '0px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' => 
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' => 
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' => 
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
        2 => 
        array (
          'elType' => 'row',
          'title' => 'Copy of Row 1',
          'columnLayout' => '1/2 + 1/2',
          'marginlessColumns' => false,
          'elements' => 
          array (
            0 => 
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' => 
              array (
                0 => 
                array (
                  'elType' => 'promo',
                  'content' => '<h3 class="man">Jillian</h3>
<h4 class="h5 man">Marketing</h4>
[x_gap size="10px"]
<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut mollis.</p>
[x_gap size="10px"]<a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="linkedin-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="facebook-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="twitter-square"] </a>',
                  'image' => 'http://placehold.it/750x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                1 => 
                array (
                  'elType' => 'gap',
                  'gap_size' => '45px',
                  'visibility' => 
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 => 
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' => 
              array (
                0 => 
                array (
                  'elType' => 'promo',
                  'content' => '<h3 class="man">Frank</h3>
<h4 class="h5 man">Legal</h4>
[x_gap size="10px"]
<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut mollis.</p>
[x_gap size="10px"] <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="linkedin-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="facebook-square"] </a> <a href="#"> [x_icon style="margin: 0 2px; font-size: 1.75em;" type="twitter-square"] </a>',
                  'image' => 'http://placehold.it/750x350/3498db/2980b9',
                  'alt' => 'Placeholder',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
              ),
            ),
            2 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/3',
              'title' => '1/3',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 => 
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'bg_color' => '',
              'padding' => 
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' => 
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' => 
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' => 
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' => 
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' => 
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'none',
      'bg_color' => '',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' => 
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' => 
      array (
        0 => '45px',
        1 => '0px',
        2 => '45px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' => 
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => 'center-text',
      'visibility' => 
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
  ),
);