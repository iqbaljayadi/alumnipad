<div class="cs-preloader" id="preloader">
  <div class="cs-preloader-logo">
    <?php echo include( CS()->path( 'includes/builder/svg/logo-flat-original.php' ) ); ?>
  </div>
  <div class="cs-preloader-text"><?php _e( 'Powered by Themeco', csl18n() ); ?></div>
</div>